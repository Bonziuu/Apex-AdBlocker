// Wydajność startu (instalacja, aktualizacja, przeładowanie, start przeglądarki).
// Pomiar: tools/perf/startup-perf.mjs. Główny koszt: każde registerContentScripts rozsyła
// pełny zestaw skryptów do wszystkich procesów kart – stąd jedna rejestracja i brak zbędnych.

import test from 'node:test';
import assert from 'node:assert/strict';
import { loadBackground } from '../helpers/chrome-mock.mjs';
import { createStartupProfiler, formatStartupProfile } from '../../background/startup-profile.js';

const ourScripts = (bg) => bg.state.registered.filter((r) => r.id.startsWith('sl-'));

test('instalacja: wszystkie pliki scriptletów w JEDNYM registerContentScripts (było: 26 wywołań)', async () => {
  const bg = await loadBackground();
  try {
    await bg.install();
    const n = ourScripts(bg).length;
    assert.ok(n >= 20, `oczekiwano ok. 26 plików, jest ${n}`);
    assert.equal(bg.state.calls.register, 1);
    assert.deepEqual(bg.state.calls.registeredInCalls, [n]);
    assert.equal(bg.state.calls.unregister, 0, 'nic do wyrejestrowania przy świeżej instalacji');
    // kolejność jak w danych (sl-<lista>-0, -1, …)
    const ids = ourScripts(bg).map((r) => r.id);
    assert.equal(ids[0], 'sl-ads-0');
    assert.ok(ids.indexOf('sl-ads-1') === 1);
  } finally { bg.restore(); }
});

/** Stan po instalacji (rejestracje + chrome.storage.local), z którego startuje nowy service worker. */
async function installedState(opts = {}) {
  const bg = await loadBackground(opts);
  try {
    await bg.install();
    return { registered: structuredClone(bg.state.registered), local: structuredClone(bg.store) };
  } finally { bg.restore(); }
}

const waitFor = async (cond) => { for (let i = 0; i < 100 && !cond(); i++) await new Promise((r) => setTimeout(r, 20)); };

test('start przeglądarki (onStartup) z poprawnie zarejestrowanymi scriptletami: zero rejestracji', async () => {
  const { registered, local } = await installedState();
  // nowy service worker po restarcie przeglądarki; rejestracje kompletne
  const bg = await loadBackground({ registered, local });
  try {
    await bg.state.listeners.startup();
    assert.equal(bg.state.calls.register, 0, 'brak registerContentScripts');
    assert.equal(bg.state.calls.unregister, 0, 'brak unregisterContentScripts');
    const h = await bg.send({ type: 'health:get' });
    assert.equal(h.sync.scriptlets.status, 'ok');
    assert.match(h.sync.scriptlets.message, /bez zmian/);
    const p = h.startupProfile;
    assert.equal(p.stages.find((x) => x.name === 'syncScriptlets').count, 1, 'jedna rzeczywista synchronizacja (start SW + onStartup)');
  } finally { bg.restore(); }
});

test('ponowna synchronizacja bez zmian: zero rejestracji; po zmianie ustawień: 1 unregister + 1 register', async () => {
  const bg = await loadBackground();
  try {
    await bg.install();
    let before = structuredClone(bg.state.calls);
    const r = await bg.send({ type: 'health:resync' });
    assert.equal(r.ok, true);
    assert.equal(bg.state.calls.register, before.register);
    assert.equal(bg.state.calls.unregister, before.unregister);
    // zmiana wymagająca innej rejestracji (pomiary wydajności → plik-flaga przed scriptletami)
    before = structuredClone(bg.state.calls);
    await bg.send({ type: 'options:setDevPerf', enabled: true });
    assert.equal(bg.state.calls.unregister - before.unregister, 1);
    assert.equal(bg.state.calls.register - before.register, 1);
    assert.ok(ourScripts(bg).every((x) => x.js[0] === 'content/scriptlet-perf-on.js'));
  } finally { bg.restore(); }
});

test('brak pliku jednego scriptletu w paczce: pozostałe zarejestrowane, błąd zgłoszony (rejestracja zastępcza)', async () => {
  const bg = await loadBackground({ failRegister: (id) => id === 'sl-ads-3' });
  try {
    await bg.install();
    const ids = ourScripts(bg).map((r) => r.id);
    assert.ok(!ids.includes('sl-ads-3'));
    assert.ok(ids.includes('sl-ads-0') && ids.includes('sl-privacy-0'));
    const h = await bg.send({ type: 'health:get' });
    assert.equal(h.sync.scriptlets.status, 'error');
    assert.match(h.sync.scriptlets.message, /sl-ads-3/);
  } finally { bg.restore(); }
});

test('start: dane kosmetyczne (kilka MB JSON) NIE są parsowane tylko po to, żeby pokazać status OK', async () => {
  const bg = await loadBackground();
  try {
    await bg.install();
    const parsed = bg.state.fetches.filter((f) => /^data\/(ads|privacy|security)\.json$/.test(f.path) && f.method === 'GET');
    assert.deepEqual(parsed, [], 'bez GET + JSON.parse danych kosmetycznych podczas instalacji');
    const h = await bg.send({ type: 'health:get' });
    assert.equal(h.components.cosmetic.status, 'ok');
    // dane wczytują się, gdy potrzebuje ich strona
    await bg.send({ type: 'cosmetic:init', url: 'https://www.example.com/' }, { tab: { id: 1, url: 'https://www.example.com/' }, frameId: 0, url: 'https://www.example.com/' });
    assert.ok(bg.state.fetches.some((f) => f.path === 'data/ads.json' && f.method === 'GET'));
  } finally { bg.restore(); }
});

test('start: metadane scriptletów (scriptlets.json, do 1,5 MB) parsowane raz na życie service workera', async () => {
  const bg = await loadBackground();
  try {
    await bg.install();
    await bg.send({ type: 'health:resync' });
    await bg.send({ type: 'health:get' });
    const n = bg.state.fetches.filter((f) => f.path === 'data/ads.scriptlets.json').length;
    assert.equal(n, 1);
  } finally { bg.restore(); }
});

test('profil startu: etapy, liczba wywołań, znaczniki i raport tekstowy', async () => {
  let t = 0;
  const p = createStartupProfiler({ now: () => t });
  p.setReason('onInstalled: update');
  p.mark('service worker: moduł wczytany');
  await p.time('scriptlety: registerContentScripts', async () => { t += 120; });
  await p.time('scriptlety: registerContentScripts', async () => { t += 30; });
  p.mark('scriptlety gotowe');
  p.finish();
  const s = p.snapshot();
  assert.equal(s.totalMs, 150);
  assert.deepEqual(s.marks, { 'service worker: moduł wczytany': 0, 'scriptlety gotowe': 150 });
  assert.deepEqual(s.stages[0], { name: 'scriptlety: registerContentScripts', count: 2, totalMs: 150, maxMs: 120, startMs: 0 });
  const text = formatStartupProfile(s);
  assert.match(text, /^Startup total: 150 ms \(onInstalled: update\)/);
  assert.match(text, /registerContentScripts: 150 ms \(2×, maks\. 120 ms\)/);
  assert.equal(formatStartupProfile(null), 'Start rozszerzenia: brak pomiaru');
});

test('profil startu jest dostępny w Diagnostyce (health:get) i przez startup:profile', async () => {
  const bg = await loadBackground();
  try {
    await bg.install();
    const h = await bg.send({ type: 'health:get' });
    assert.ok(h.startupProfile && h.startupProfile.totalMs !== null);
    assert.match(h.startupProfile.reason, /onInstalled/);
    const r = await bg.send({ type: 'startup:profile' });
    assert.match(r.text, /^Startup total: /);
    assert.ok(r.profile.marks['DNR gotowy'] !== undefined);
  } finally { bg.restore(); }
});

const sessionRegs = (bg) => bg.state.registered.filter((r) => r.id.startsWith('sl-') && r.persistAcrossSessions === false);

// Older snapshots used concrete TLD-expanded session patterns. Exercise their
// recovery explicitly instead of assuming the current build still emits them.
const legacyFiles = {
  'data/ads.scriptlets.json': [{ file: 'scriptlets/ads-0.js', matches: ['*://*.legacy.example/*'], sessionMatches: ['*://*.legacy.fr/*'] }],
  'data/privacy.scriptlets.json': [],
  'data/security.scriptlets.json': [],
};

test('zgodność starszych metadanych: utrwalane przed sesyjnymi, obie w jednym wywołaniu', async () => {
  const bg = await loadBackground({ files: legacyFiles });
  try {
    await bg.install();
    const regs = ourScripts(bg);
    const firstSession = regs.findIndex((r) => r.persistAcrossSessions === false);
    assert.ok(firstSession > 0, 'są rejestracje sesyjne');
    assert.ok(regs.slice(0, firstSession).every((r) => r.persistAcrossSessions === true));
    assert.ok(regs.slice(firstSession).every((r) => r.persistAcrossSessions === false && r.id.endsWith('-s')));
    assert.equal(bg.state.calls.register, 1);
    for (const r of regs) { assert.equal(r.world, 'MAIN'); assert.equal(r.runAt, 'document_start'); assert.equal(r.allFrames, false); }
    const persisted = regs.filter((r) => r.persistAcrossSessions).reduce((n, r) => n + r.matches.length, 0);
    const session = sessionRegs(bg).reduce((n, r) => n + r.matches.length, 0);
    assert.equal(persisted, 1);
    assert.equal(session, 1);
  } finally { bg.restore(); }
});

test('starszy snapshot po restarcie: dorejestrowujemy WYŁĄCZNIE część sesyjną, raz', async () => {
  const { registered, local } = await installedState({ files: legacyFiles });
  const persisted = registered.filter((r) => r.persistAcrossSessions !== false);
  const nSession = registered.length - persisted.length;
  const bg = await loadBackground({ registered: persisted, local, files: legacyFiles });
  try {
    await bg.state.listeners.startup();
    await waitFor(() => bg.state.calls.register > 0);
    assert.equal(bg.state.calls.unregister, 0, 'utrwalone nie są ruszane');
    assert.equal(bg.state.calls.register, 1, 'jedna rejestracja (start SW i onStartup razem)');
    assert.equal(bg.state.calls.registeredInCalls[0], nSession, 'tylko rejestracje sesyjne');
    assert.equal(sessionRegs(bg).length, nSession);
    const h = await bg.send({ type: 'health:get' });
    assert.equal(h.sync.scriptlets.status, 'ok');
    assert.match(h.sync.scriptlets.message, /dorejestrowano część sesyjną/);
    assert.equal(h.startupProfile.stages.find((x) => x.name === 'syncScriptlets').count, 1);
  } finally { bg.restore(); }
});

test('starszy snapshot po ponownym włączeniu: część sesyjna odtwarzana przy starcie workera', async () => {
  const bg = await loadBackground({ files: legacyFiles });
  let persistedOnly;
  let local;
  try {
    await bg.install();
    persistedOnly = bg.state.registered.filter((r) => r.persistAcrossSessions !== false);
    local = structuredClone(bg.store);
  } finally { bg.restore(); }
  // nowy service worker: utrwalone rejestracje i ustawienia są, części sesyjnej i storage.session brak
  const bg2 = await loadBackground({ registered: persistedOnly, local, files: legacyFiles });
  try {
    for (let i = 0; i < 100 && bg2.state.calls.register === 0; i++) await new Promise((r) => setTimeout(r, 20));
    assert.equal(bg2.state.calls.register, 1, 'jedna rejestracja przy starcie SW');
    assert.equal(bg2.state.calls.unregister, 0, 'utrwalone nie są ruszane');
    const added = bg2.state.registered.slice(persistedOnly.length);
    assert.ok(added.length > 0 && added.every((r) => r.persistAcrossSessions === false), 'tylko część sesyjna');
    // kolejny start SW w tej samej sesji (znacznik w storage.session) – zero pracy
    assert.equal(bg2.session.sessionScriptletsOk, true);
  } finally { bg2.restore(); }
});

test('aktualny build: strzeżone encje przeżywają restart bez ponownej rejestracji', async () => {
  const { registered, local } = await installedState();
  const entities = registered.filter((r) => r.js.some((file) => file.endsWith('-entities.js')));
  assert.ok(entities.length > 0);
  assert.ok(entities.every((r) => r.persistAcrossSessions === true && r.matches.includes('*://*/*')));
  assert.ok(registered.every((r) => r.persistAcrossSessions === true));
  const bg = await loadBackground({ registered, local });
  try {
    await bg.state.listeners.startup();
    assert.equal(bg.state.calls.register, 0);
    assert.equal(bg.state.calls.unregister, 0);
    assert.equal(ourScripts(bg).length, registered.length);
    assert.equal(bg.session.sessionScriptletsOk, true);
  } finally { bg.restore(); }
});

for (const reason of ['update', 'install']) {
  test(`regresja: onInstalled:${reason} → dokładnie jedna rzeczywista synchronizacja scriptletów`, async () => {
    // nowy service worker: Chrome wyczyścił rejestracje i chrome.storage.session; start SW
    // (brak znacznika sesji) i onInstalled chcą zsynchronizować – ma być jedna synchronizacja
    const bg = await loadBackground();
    try {
      await bg.state.listeners.installed({ reason });
      const p = (await bg.send({ type: 'startup:profile' })).profile;
      const stage = (n) => p.stages.find((x) => x.name === n) || { count: 0, totalMs: 0 };
      assert.equal(stage('syncScriptlets').count, 1, 'syncScriptlets wykonane raz');
      assert.equal(stage('scriptlety: getRegisteredContentScripts').count, 1, 'jedno porównanie z Chrome');
      assert.equal(stage('scriptlety: registerContentScripts').count, 1);
      assert.equal(bg.state.calls.register, 1);
      assert.equal(bg.state.calls.unregister, 0);
      assert.ok(stage('syncScriptlets: dołączenie do trwającej/wykonanej synchronizacji').count >= 1, 'drugi chętny dołączył zamiast synchronizować');
      // czas oczekiwania w kolejce raportowany osobno od wykonania
      assert.ok(p.stages.some((x) => x.name === 'syncScriptlets: oczekiwanie w kolejce'));
      assert.match(p.reason, new RegExp(`onInstalled: ${reason}`));
      const h = await bg.send({ type: 'health:get' });
      assert.equal(h.sync.scriptlets.status, 'ok');
    } finally { bg.restore(); }
  });
}

test('po inicjalnej synchronizacji zmiana ustawień nadal synchronizuje naprawdę (nie dołącza do inicjalnej)', async () => {
  const bg = await loadBackground();
  try {
    await bg.state.listeners.installed({ reason: 'update' });
    const before = bg.state.calls.register;
    await bg.send({ type: 'options:setDevPerf', enabled: true });
    assert.equal(bg.state.calls.register, before + 1);
    assert.ok(ourScripts(bg).every((r) => r.js[0] === 'content/scriptlet-perf-on.js'));
    const p = (await bg.send({ type: 'startup:profile' })).profile;
    assert.equal(p.stages.find((x) => x.name === 'syncScriptlets').count, 2, 'inicjalna + zmiana ustawień');
  } finally { bg.restore(); }
});

test('profil startu: oczekiwanie w kolejce liczone osobno od wykonania', async () => {
  let t = 0;
  const p = createStartupProfiler({ now: () => t });
  p.add('syncScriptlets: oczekiwanie w kolejce', 700);
  await p.time('syncScriptlets', async () => { t += 30; });
  const s = p.snapshot();
  assert.equal(s.stages.find((x) => x.name === 'syncScriptlets').totalMs, 30);
  assert.equal(s.stages.find((x) => x.name === 'syncScriptlets: oczekiwanie w kolejce').totalMs, 700);
});
